#OpenVX-based HAL implementation.
It's built when OpenVX is available (`HAVE_OPENVX`).
To build OpenCV with OpenVX support add the following **cmake** options:
`-DOPENVX_ROOT=/path/to/prebuilt/openvx -DWITH_OPENVX=YES`